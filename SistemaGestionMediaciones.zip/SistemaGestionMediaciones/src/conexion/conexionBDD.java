package conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class conexionBDD {
    
    private static final String CADENA_CONEX = "jdbc:postgresql://localhost:5432/DatabaseSGM";
    private static final String USUARIO = "postgres";
    private static final String CONTRASENA = "Fernando18@";
    
    static {
        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, "Error al cargar el driver de PostgreSQL: " + e.getMessage());
        }
    }
    
    public static Connection obtenerConexion() throws SQLException {
        return DriverManager.getConnection(CADENA_CONEX, USUARIO, CONTRASENA);
    }

    public static void cerrarConexion(Connection conex) {
        if (conex != null) {
            try {
                conex.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Error al cerrar la conexión: " + e.getMessage());
            }
        }
    }
}
