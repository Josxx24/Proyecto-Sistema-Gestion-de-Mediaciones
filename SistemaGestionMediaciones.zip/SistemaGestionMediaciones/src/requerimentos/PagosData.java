/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package requerimentos;

/**
 *
 * @author josel
 */
public class PagosData {
    private String fecha;
    private String apertura;
    private double tarifa;
    private double montoCentro;
    private double subtotal;
    private double total;
    private double valorPagado;

    // Getters y Setters para cada campo
    public String getFecha() { return fecha; }
    public void setFecha(String fecha) { this.fecha = fecha; }
    
    public String getApertura() { return apertura; }
    public void setApertura(String apertura) { this.apertura = apertura; }
    
    public double getTarifa() { return tarifa; }
    public void setTarifa(double tarifa) { this.tarifa = tarifa; }
    
    public double getMontoCentro() { return montoCentro; }
    public void setMontoCentro(double montoCentro) { this.montoCentro = montoCentro; }
    
    public double getSubtotal() { return subtotal; }
    public void setSubtotal(double subtotal) { this.subtotal = subtotal; }
    
    public double getTotal() { return total; }
    public void setTotal(double total) { this.total = total; }
    
    public double getValorPagado() { return valorPagado; }
    public void setValorPagado(double valorPagado) { this.valorPagado = valorPagado; }
}
