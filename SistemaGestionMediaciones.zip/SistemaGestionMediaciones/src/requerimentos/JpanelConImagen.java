/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package requerimentos;

import java.awt.Graphics;
import java.awt.Image;
import java.net.URL;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

/**
 *
 * @author Fernando Aldaz
 */
public class JpanelConImagen extends JPanel{
    private URL url = getClass().getResource("/imagenes/fondo.jpg");
    Image image = new ImageIcon(url).getImage();

    @Override
    protected void paintComponent(Graphics grphcs) {
        super.paintComponent(grphcs);
        grphcs.drawImage(image, 0, 0, getWidth(), getHeight(), this);
       
    }
}
